import time
import random

def print_pause(message_to_print):
    print(message_to_print)
    time.sleep(2)

def valid_input(prompt, option1, option2):
    while True:
        response = input(prompt).lower()
        if option1 in response:
            break
        elif option2 in response:
            break
        else:
            print_pause("Sorry, I don't understand.")
    return response

def intro():
    print_pause("It's been five days and the cruise you are on with "
                "your family will return to dock in two days.\n")
    print_pause("You just finished your third viewing of the onboard "
                "ventriloquist when, all of a suddon, you feel the "
                "ship violently back and forth.\n")
    print_pause("Everything seems hazy as your hear the captain speaking "
                "over the intercom 'Our ship…sinking…don’t panic…lifeboats…"
                "immediately'\n")
    print_pause("The scene on the ship is chaotic as people fight for "
                "space on the lifeboats.\n")
    print_pause("You are separated from your family as a member of the "
                "ship’s crew ushers you to one of the lifeboat.\n")
    print_pause("You put on a spare life preserver and get pushed into "
                "the lifeboat.\n")
    print_pause("As the lifeboat is lowered into the water, the rope "
                "snaps, the lifeboat drops, and everything goes black…\n")
    print_pause("You wake up all alone in the lifeboat to the sound of "
                "birds chirping on the shore of a deserted island.\n")
    print_pause("You’re not sure what happened to the rest of the passengers, "
                "but you are sunburnt, afraid, and hungry.\n")
def Lifeboat(items):
    print_pause("You scan the lifeboat for any items of use.\n")
    if "hammer" in items:
        print_pause("You grab the item that you think would be helpful, so "
                    "there is nothing more that you need.\n")
        find_food(items)
    else:
        print_pause("In the lifeboat, you find mostly useless items, but your eyes "
                    "linger upon what appears to be a hammer. \n")
        items.append("hammer")
        print_pause("You grab the hammer and leave the lifeboat.\n")
        find_food(items)

def Cave(items):
    print_pause("There is a dark cave at the end of the beach.\n")
    print_pause("It looks very scary, but you know that you might find "
                "something of use or potentially something to eat.\n")
    print_pause("Within the dank, murky cave, you see an object "
                "glimmering deep within.\n")
    if "diamond" in items:
        print_pause ("It seems like you got the diamond that you need.\n")
        print_pause("There doesn't seem to be much to do here.\n")
    elif "hammer" in items:
        print_pause("You try to grab the shiny object, but it is stuck "
                    "in the ground. You use the hammer to dislodge the "
                    "item - a diamond.\n")
        print_pause("You may now leave the cave.\n") 
        items.append("diamond")
        find_food(items)
    else:
        print_pause("You can see the shiny object but can't get it out until "
                    "you have something to dig it out with, like a "
                    "hammer.\n")
        print_pause("You head back to the lifeboat to see if you can find "
                    "something useful.\n")
        find_food(items)

def Mountain(items):
    print_pause("You begin your ascent to the top of the mountain in hopes of "
                "finding food or at least to get a view of the island.\n")
    print_pause("Panting heavily following your climb, you stumble upon a "
                "wizard at the top of the mountain (you know he’s a wizard "
                "because of his pointy hat and long robe).\n")
    print_pause("You ask the wizard if he has some food to share. He replies "
                "that he does, but that he needs something valuable to part "
                "with that food.\n")
    if "hammer" in items:
        print_pause("You offer the hammer from the lifeboat, but the wizard "
                    "scoffs, saying that won’t be enough.\n")
    if "diamond" in items:
        print_pause("You offer the diamond from the cave. The wizard’s eyes "
                    "light up. He accepts the diamond and in return, gives "
                    "you food. \n")
        name_list = ['Cooked chicken', 'Tomato', 'Zucchini', 'Peppers', 'Banana',
                    'Coffee','Steak', 'Whipped Cream', 'Fries', 'Biscuits (no gravy)',
                    'Edible arrangement', 'Frostee']
        namee_list = random.choice(name_list)
        print("The food he gives you is: ", namee_list)
        play_again()
    else:
        print_pause("Unfortunately, you need something shiny like a diamond "
                    "in exchange for food.\n")
        print_pause("So you head back down to find the diamond.\n")
        find_food(items)

        
def find_food(items):
    print_pause("Please enter the number for location you want to visit:\n")
    location=input("1.Lifeboat\n"
                   "2.Cave\n"
                   "3.Mountain\n")

    if location =='1':
        Lifeboat(items)
    elif location =='2':
        Cave(items)
    elif location =='3':
        Mountain(items)
    else:
        print("I don't understand. Please try again.")
        find_food(items)


def play_again():
    response = valid_input("Would you like to play again? "
                           "Please say 'yes' or 'no'.\n",
                           "yes", "no")
    if "no" in response:
        print_pause("ok, goodbye!")
    elif "yes" in response:
        print_pause("Very good, let's play one more time!")
        play_game()
        
def play_game():
    items = []
    intro ()
    find_food(items)
    
play_game()
